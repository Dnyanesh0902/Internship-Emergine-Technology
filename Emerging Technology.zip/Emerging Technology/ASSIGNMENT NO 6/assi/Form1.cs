﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics;

namespace assi
{
    public partial class Form1 : Form
    {
        private readonly object listBox1;
        Process[] p;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = "calc";
            p.Start();
            //button3_Click(sender, e);
           button3_Click(null, null);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            p.StartInfo.Arguments = textBox1.Text;
            p.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            List.Items.Clear();
            Process[] p = Process.GetProcesses();
            for (int i = 0; i < p.Length; i++)
            {
                List.Items.Add(p[i].ProcessName);
            }
            List.Sorted = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process[] process2 = Process.GetProcessesByName(List.SelectedItem.ToString());
            foreach (Process process1 in process2)
            {
                process1.Kill();
            }
            button3_Click(null, null);
        }
        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void List_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3_Click(null, null);
        }
    }
}
