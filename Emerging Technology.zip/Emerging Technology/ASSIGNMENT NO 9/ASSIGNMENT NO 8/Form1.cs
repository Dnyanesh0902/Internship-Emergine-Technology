﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.Threading;
using System.Windows.Forms;

namespace ASSIGNMENT_NO_8
{
    
    public partial class Form1 : Form
    {
        SpeechSynthesizer ss = new SpeechSynthesizer();
        PromptBuilder pb = new PromptBuilder();
        SpeechRecognitionEngine sre = new SpeechRecognitionEngine();
        Choices clist = new Choices();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            BtnStart.Enabled = false;
            BtnStop.Enabled = true;
            clist.Add(new string[] { "Hello", "Good Morning", "Welcome", "Thank You" });  // this is custom grammar
            Grammar gr = new Grammar(new GrammarBuilder(clist));
            //Grammar gr = new DictationGrammar();        //this is system grammar
            try
            {
                sre.RequestRecognizerUpdate();
                sre.LoadGrammar(gr);
                sre.SetInputToDefaultAudioDevice();
                sre.SpeechRecognized +=sre_SpeechRecognized;
                sre.RecognizeAsync(RecognizeMode.Multiple);
            }
            catch(Exception ex) { MessageBox.Show(ex.Message, "Error"); }
        }

        private void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + e.Result.Text.ToString() + Environment.NewLine;

        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            sre.RecognizeAsyncStop();
            BtnStart.Enabled = true;
            BtnStop.Enabled = false;
        }
    }
}
