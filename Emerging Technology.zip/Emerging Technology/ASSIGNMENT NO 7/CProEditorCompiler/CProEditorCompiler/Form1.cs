﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CProEditorCompiler
{
    public partial class Form1 : Form
    {
        Process process = new Process();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Text = File.ReadAllText(openFileDialog1.FileName);
                process.StartInfo.Arguments = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.FileName == "openFileDialog1")
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog1.FileName, richTextBox1.Text);
                    process.StartInfo.Arguments = saveFileDialog1.FileName;
                }
            }
            else
            {
                File.WriteAllText(openFileDialog1.FileName, richTextBox1.Text);
                process.StartInfo.Arguments = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (process.StartInfo.Arguments != string.Empty)
            {
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.RedirectStandardOutput = true;

                process.StartInfo.UseShellExecute = false;


                process.StartInfo.FileName = "node";
                process.Start();
                try
                {
                    StreamReader streamReader = process.StandardOutput;
                    richTextBox2.ForeColor = Color.White;
                    richTextBox2.Text = streamReader.ReadToEnd();
                    StreamReader streamReader1 = process.StandardError;
                    if (streamReader1.ReadToEnd() != string.Empty)
                    {
                        MessageBox.Show("Program Contain Error");
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }




        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            string patternforint = @"\b(?:(?:const\s*|let\s*|var\s*)+)(?:\s+\*?\*?\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*[\[;,=)]";
            Regex regex = new Regex(patternforint, RegexOptions.Compiled | RegexOptions.IgnoreCase);
            MatchCollection matchCollection = regex.Matches(richTextBox1.Text);
            Console.WriteLine(matchCollection.Count.ToString());
            label2.Text = matchCollection.Count.ToString();
        }
    }
}
