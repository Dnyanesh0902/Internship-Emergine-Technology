﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.folder_click = new System.Windows.Forms.Button();
            this.file_click = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(159, 146);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(347, 22);
            this.textBox1.TabIndex = 1;
            // 
            // folder_click
            // 
            this.folder_click.Location = new System.Drawing.Point(472, 311);
            this.folder_click.Name = "folder_click";
            this.folder_click.Size = new System.Drawing.Size(105, 42);
            this.folder_click.TabIndex = 2;
            this.folder_click.Text = "Folder";
            this.folder_click.UseVisualStyleBackColor = true;
            this.folder_click.Click += new System.EventHandler(this.button1_Click);
            // 
            // file_click
            // 
            this.file_click.Location = new System.Drawing.Point(85, 311);
            this.file_click.Name = "file_click";
            this.file_click.Size = new System.Drawing.Size(118, 42);
            this.file_click.TabIndex = 3;
            this.file_click.Text = "File";
            this.file_click.UseVisualStyleBackColor = true;
            this.file_click.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 454);
            this.Controls.Add(this.file_click);
            this.Controls.Add(this.folder_click);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button folder_click;
        private System.Windows.Forms.Button file_click;
    }
}

