﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SplashScreenAssignment
{
    internal class FireBaseConf
    {
        //public static string url = "https://register-58688-default-rtdb.firebaseio.com/";
        public static string url = "https://register-58688-default-rtdb.firebaseio.com/";
    }
}
